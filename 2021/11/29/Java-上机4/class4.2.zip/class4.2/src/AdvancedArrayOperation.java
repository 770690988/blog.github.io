public interface AdvancedArrayOperation {
    int binarySearch(int key);
    void quickSort(int left, int right);
    void shuffle(int num);
}
