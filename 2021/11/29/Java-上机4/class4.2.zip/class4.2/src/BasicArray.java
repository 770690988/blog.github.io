public abstract class BasicArray {
    int[] myList;
    abstract public void setArray(int[] array);
}
