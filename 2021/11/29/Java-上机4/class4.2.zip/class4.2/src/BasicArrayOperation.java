public interface BasicArrayOperation{
    int getMaxValue();
    int getMinValue();
    void insert(int index, int key);
    void move(String direction, int offset);
    void printArray();


}
