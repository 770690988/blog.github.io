﻿#include "Mi.h"
cgn = 0;
difficult = 1;
monstern = 1;
mode = 2;
monster = 3;
life = 1;
Life = 1;
shop = 1;
set = 1;
rmb = 50;
gun = 0;
knife = 0;
TIME = 55000; //TIME = 15*1000 + difficult * 40000;
times = 30;
cycle = 0;
eatpeople = 1;
People people;
People peoplenext;
Jiangshi jshi;
Money money;

//音乐模块
void d1music()
{
    Beep(262,200);
}

void d2music()
{
    Beep(294,200);
}

void d3music()
{
    Beep(330,200);
}

void d4music()
{
    Beep(349,200);
}

void d5music()
{
    Beep(392,200);
}

void d6music()
{
    Beep(440,200);
}

void d7music()
{
    Beep(494,200);
}

void music1()
{
    Beep(523, 200);
}

void music2()
{
    Beep(578, 200);
}

void music3()
{
    Beep(659, 200);
}

void music4()
{
    Beep(698, 200);
}

void music5()
{
    Beep(784, 200);
}

void music6()
{
    Beep(880, 200);
}

void music7()
{
    Beep(988, 200);
}

void music1q()
{
    Beep(1046, 200);
}

void music2q()
{
    Beep(1175, 200);
}

void music3q()
{
    Beep(1318, 200);
}

void music4q()
{
    Beep(1480, 200);
}

void music5q()
{
    Beep(1568, 200);
}

void music6q()
{
    Beep(1760, 200);
}

void music7q()
{
    Beep(1976, 200);
}

//胜利音效
void winmusic()
{
    music1();
    music1();
    music5();
    music5();
    music6();
    music6();
    music5();
    Sleep(500);
    music4();
    music4();
    music3();
    music3();
    music2();
    music2();
    music1();
}

//天空之城
void heavensong()
{
    int pai = 400, ban = 200;
    int ting = 128;
    Sleep(1000);

    Beep(la, ban);
    Beep(si, ban);
    Sleep(ting);

    Beep(do1, pai + ban);
    Beep(si, ban);
    Sleep(ting);
    Beep(do1, pai);
    Sleep(ting);
    Beep(mi1, pai);
    Sleep(ting);

    Beep(si, 3 * pai);
    Sleep(ting);
    Beep(mi, ban);
    Beep(mi, ban);

    Beep(la, ban + pai);
    Beep(so, ban);
    Sleep(ting);
    Beep(la, pai);
    Sleep(ting);
    Beep(do1, pai);
    Sleep(ting);

    Beep(so, 2 * pai);
    Sleep(ting);
    Sleep(pai);
    Beep(mi, ban);
    Sleep(ting / 2);
    Beep(mi, ban);
    Sleep(ting / 2);

    Beep(fa, pai + ban);
    Beep(mi, ban);
    Sleep(ting);
    Beep(fa, ban);
    Beep(do1, ban + pai);
    Sleep(ting);

    Beep(mi, 2 * pai);
    Sleep(ting);
    Sleep(ban);
    Beep(do1, ban);
    Sleep(ting / 2);
    Beep(do1, ban);
    Sleep(ting / 2);
    Beep(do1, ban);
    Sleep(ting / 2);

    Beep(si, ban + pai);
    Beep(sfa, ban);
    Sleep(ting);
    Beep(sfa, pai);
    Beep(si, pai);
    Sleep(ting);

    Beep(si, 2 * pai);
    Sleep(ting);
    Sleep(pai);
    Beep(la, ban);
    Beep(si, ban);
    Sleep(ting);

    Beep(do1, pai + ban);
    Beep(si, ban);
    Sleep(ting);
    Beep(do1, pai);
    Sleep(ting);
    Beep(mi1, pai);
    Sleep(ting);

    Beep(si, 2 * pai);
    Sleep(ting);
    Sleep(pai);
    Beep(mi, ban);
    Sleep(20);
    Beep(mi, ban);
    Sleep(ting);

    Beep(la, pai + ban);
    Beep(so, ban);
    Sleep(ting);
    Beep(la, pai);
    Sleep(ting);
    Beep(do1, pai);
    Sleep(ting);

    Beep(so, 3 * pai);
    Sleep(ting + ban);
    Beep(mi, ban);
    Sleep(ting / 2);

    Beep(fa, pai);
    Sleep(ting);
    Beep(do1, ban);
    Beep(si, ban);
    Sleep(20);
    Beep(si, pai);
    Sleep(ting);
    Beep(do1, pai);
    Sleep(ting);

    Beep(re1, ban);
    Sleep(20);
    Beep(re1, ban);
    Sleep(20);
    Beep(mi1, ban);
    Sleep(ting / 2);
    Beep(do1, pai);
    Sleep(ting + pai);

    Beep(do1, pai);
    Beep(si, ban);
    Sleep(ting);
    Beep(la, ban);
    Sleep(20);
    Beep(la, ban);
    Sleep(ting);
    Beep(si, pai);
    Sleep(ting);
    Beep(sso, pai);
    Sleep(ting);

    Beep(sso, 2 * pai);
    Sleep(ting + pai);
    Beep(do1, ban);
    Beep(re1, ban);
    Sleep(ting);

    Beep(mi1, pai + ban);
    Beep(re1, ban);
    Sleep(ting);
    Beep(mi1, pai);
    Sleep(ting);
    Beep(fa1, pai);
    Sleep(ting);

    Beep(re1, 2 * pai);
    Sleep(pai + ting);
    Beep(so, ban);
    Sleep(20);
    Beep(so, ban);
    Sleep(ting);

    Beep(do1, ban);
    Beep(si, ban);
    Sleep(ting);
    Beep(do1, pai);
    Sleep(ting);
    Beep(mi1, pai);
    Sleep(ting);

    Beep(mi1, 2 * pai);
    Sleep(ting + 2 * pai);

    Beep(la, ban);
    Beep(si, ban);
    Sleep(ting);
    Beep(do1, pai);
    Sleep(ting);
    Beep(si, pai);
    Sleep(ting);
    Beep(re1, ban);
    Sleep(20);
    Beep(re1, ban);
    Sleep(ting);

    Beep(do1, pai + ban);
    Beep(so, ban);
    Sleep(20);
    Beep(so, pai);
    Sleep(pai + ting);

    Beep(fa1, pai);
    Sleep(ting);
    Beep(mi1, pai);
    Sleep(ting);
    Beep(re1, pai);
    Sleep(ting);
    Beep(do1, pai);
    Sleep(ting);

    Beep(mi1, 4 * pai);

    Beep(mi1, pai * 2);
    Sleep(pai + ting);
    Beep(mi1, pai);
    Sleep(ting);

    Beep(la1, 2 * pai);
    Sleep(ting);
    Beep(so1, pai);
    Sleep(ting);
    Beep(so1, pai);
    Sleep(ting);

    Beep(mi1, ban);
    Sleep(ting / 2);
    Beep(re1, ban);
    Sleep(ting);
    Beep(do1, pai);
    Sleep(ting + ban);
    Beep(do1, ban);
    Sleep(ting);

    Beep(re1, pai);
    Sleep(ting);
    Beep(do1, ban);
    Beep(re1, ban);
    Sleep(20);
    Beep(re1, ban);
    Sleep(ting);
    Beep(so1, pai);
    Sleep(ting);

    Beep(mi1, 2 * pai);
    Sleep(ting + pai);
    Beep(mi, pai);
    Sleep(ting);

    Beep(la1, 2 * pai);
    Sleep(ting);
    Beep(so1, 2 * pai);
    Sleep(ting);

    Beep(mi1, ban);
    Beep(re1, ban);
    Sleep(ting);
    Beep(do1, 2 * pai);
    Sleep(ting + ban);
    Beep(do1, ban);
    Sleep(ting);

    Beep(re1, pai);
    Sleep(ting);
    Beep(do1, ban);
    Beep(re1, ban);
    Sleep(20);
    Beep(re1, ban);
    Sleep(ting);
    Beep(si, pai);
    Sleep(ting);

    Beep(la, 2 * pai);
    Sleep(ting);
    Beep(la, ban);
    Beep(si, ban);

    Beep(do1, pai + ban);
    Beep(si, ban);
    Sleep(ting);
    Beep(do1, pai);
    Sleep(ting);
    Beep(mi1, pai);
    Sleep(ting);

    Beep(si, 3 * pai);
    Sleep(ting);
    Beep(mi, ban);
    Beep(mi, ban);

    Beep(la, ban + pai);
    Beep(so, ban);
    Sleep(ting);
    Beep(la, pai);
    Sleep(ting);
    Beep(do1, pai);
    Sleep(ting);

    Beep(so, 2 * pai);
    Sleep(ting);
    Sleep(pai);
    Beep(mi, ban);
    Sleep(ting / 2);
    Beep(mi, ban);
    Sleep(ting / 2);

    Beep(fa, pai + ban);
    Beep(mi, ban);
    Sleep(ting);
    Beep(fa, ban);
    Beep(do1, ban + pai);
    Sleep(ting);

    Beep(mi, 2 * pai);
    Sleep(ting);
    Sleep(ban);
    Beep(do1, ban);
    Sleep(ting / 2);
    Beep(do1, ban);
    Sleep(ting / 2);
    Beep(do1, ban);
    Sleep(ting / 2);

    Beep(si, ban + pai);
    Beep(sfa, ban);
    Sleep(ting);
    Beep(sfa, pai);
    Beep(si, pai);
    Sleep(ting);

    Beep(si, 2 * pai);
    Sleep(ting);
    Sleep(pai);
    Beep(la, ban);
    Beep(si, ban);
    Sleep(ting);

    Beep(do1, pai + ban);
    Beep(si, ban);
    Sleep(ting);
    Beep(do1, pai);
    Sleep(ting);
    Beep(mi1, pai);
    Sleep(ting);

    Beep(si, 2 * pai);
    Sleep(ting);
    Sleep(pai);
    Beep(mi, ban);
    Sleep(20);
    Beep(mi, ban);
    Sleep(ting);

    Beep(la, pai + ban);
    Beep(so, ban);
    Sleep(ting);
    Beep(la, pai);
    Sleep(ting);
    Beep(do1, pai);
    Sleep(ting);

    Beep(so, 3 * pai);
    Sleep(ting + ban);
    Beep(mi, ban);
    Sleep(ting / 2);

    Beep(fa, pai);
    Sleep(ting);
    Beep(do1, ban);
    Beep(si, ban);
    Sleep(20);
    Beep(si, pai);
    Sleep(ting);
    Beep(do1, pai);
    Sleep(ting);

    Beep(re1, ban);
    Sleep(20);
    Beep(re1, ban);
    Sleep(20);
    Beep(mi1, ban);
    Sleep(ting / 2);
    Beep(do1, pai);
    Sleep(ting + pai);

    Beep(la, 4 * pai);

    Sleep(1000);
}

//光标定位函数
void GotoXY(int x, int y)
{
    HANDLE hout;
    COORD cor;
    hout = GetStdHandle(STD_OUTPUT_HANDLE);
    cor.X = x;
    cor.Y = y;
    SetConsoleCursorPosition(hout, cor);
}

//隐藏光标
void Hide()
{
    HANDLE hout = GetStdHandle(STD_OUTPUT_HANDLE);
    CONSOLE_CURSOR_INFO cor_info = { 1, 0 };
    SetConsoleCursorInfo(hout, &cor_info);//隐藏光标

}

//菜单页面
int Menu()
{
    Hide();
    GotoXY(36, 12);   //定位光标的位置
    printf(ORED"欢迎来到智慧迷宫游戏");
    GotoXY(43, 14);
    printf("1. 开始游戏");
    GotoXY(43, 16);
    printf("2. 设置");
    GotoXY(43, 18);
    printf("3. 帮助");
    GotoXY(43, 20);
    printf("4. 关于(请谨慎进入因为进入可能要好久才能出来)");
    GotoXY(43, 22);
    printf("退出游戏请输入     0"NONE);
    Hide();    //隐藏光标
    char ch;
    int result = 1;
    ch = _getch();
    switch (ch)
    {
    case '1': result = 1; break;
    case '2': result = 2; break;
    case '3': result = 3; break;
    case '4': result = 4; break;
    case '0': result = 0; break;
    default:  result = 5; break;
    }
    system("cls");  //清空当前页面
    
    return result;
}

//设置页面
int setting()
{
    Hide();
    system("cls");
    GotoXY(40, 10);
    printf(GREEN"地图设置请输入     1");
    GotoXY(40, 12);
    printf("模式设置请输入     2");
    GotoXY(40, 14);
    printf("生命值设置请输入   3");
    GotoXY(40, 16);
    printf("商店设置请输入     4");
    GotoXY(45, 18);
    printf("按其他任意键返回上一级"NONE);
    char ch = _getch();
    system("cls");
    switch (ch)
    {
    case '1':
        mapset();
        break;
    case '2':
        modeset();
        break;
    case '3':
        lifeset();
        break;
    case '4':
        shopset();
        break;
    }
    return 0;
    
}

//地图设置
int mapset()
{
    Hide();
    GotoXY(40, 14);
    printf("输入1-6的正整数来表示迷宫的大小");
    GotoXY(40, 16);
    printf("当前迷宫的大小系数为   %d", difficult);
    GotoXY(45, 18);
    printf("按其他任意键设置怪物数量等级");
    char ch = _getch();
    system("cls");
    switch (ch)
    {
    case '1':
        difficult = 1;
        break;
    case '2':
        difficult = 2;
        break;
    case '3':
        difficult = 3;
        break;
    case '4':
        difficult = 4;
        break;
    case '5':
        difficult = 5;
        break;
    case '6':
        difficult = 6;
        break;
    }
    height = HEIGHT + 4 * difficult ;
    width = WIDTH + 4 * difficult ;
    TIME = 15*1000 + difficult * 40000;
    system("cls");
    GotoXY(40, 14);
    printf("输入1-7中的一个数表示迷宫怪物数量等级");
    GotoXY(40, 16);
    printf("当前怪物数量等级为   %d", monstern);
    GotoXY(45, 18);
    printf("按其他任意键返回主菜单");
    ch = _getch();
    system("cls");
    switch (ch)
    {
    case '1':
        monstern = 1;
        break;
    case '2':
        monstern = 2;
        break;
    case '3':
        monstern = 3;
        break;
    case '4':
        monstern = 4;
        break;
    case '5':
        monstern = 5;
        break;
    case '6':
        monstern = 6;
        break;
    case '7':
        monstern = 7;
        break;
    }
    monster = 3 + monstern;
    return monster;
}

//找到合适的路
int fdmap()
{
    int stmap[54][54];
    int i, j;
    i = j = 1;
    
    for (i = 1; i <= width; i++) {   //对找到的位置进行初始化
        for (j = 1; j <= height; j++) {
            stmap[i][j] = map[i][j];
        }
    }
    i = 1;
    j = 1;
    mapx[i] = 2;
    mapy[j] = 2;
    stmap[mapx[i]][mapy[j]] = 10;
    while (stmap[mapx[i]][mapy[j]] != chu) {
        if (stmap[mapx[i] + 1][mapy[j]] == road || stmap[mapx[i] + 1][mapy[j]] == jinbi || stmap[mapx[i] + 1][mapy[j]] == chu) {
            if (stmap[mapx[i] + 1][mapy[j]] == chu) {
                break;
            }
            stmap[mapx[i] + 1][mapy[j]] = 10;
            mapx[i + 1] = mapx[i] + 1;
            mapy[j + 1] = mapy[j];
            i++;
            j++;
            printHead(i,1);
        }
        else if (stmap[mapx[i] - 1][mapy[j]] == road || stmap[mapx[i] - 1][mapy[j]] == jinbi || stmap[mapx[i] - 1][mapy[j]] == chu) {
            if (stmap[mapx[i] - 1][mapy[j]] == chu) {
                break;
            }
            stmap[mapx[i] - 1][mapy[j]] = 10;
            mapx[i + 1] = mapx[i] - 1;
            mapy[j + 1] = mapy[j];
            i++;
            j++;
            printHead(i,1);
        }
        else if (stmap[mapx[i]][mapy[j] + 1] == road || stmap[mapx[i]][mapy[j] + 1] == jinbi || stmap[mapx[i]][mapy[j] + 1] == chu) {
            if (stmap[mapx[i]][mapy[j] + 1] == chu) {
                break;
            }
            stmap[mapx[i]][mapy[j] + 1] = 10;
            mapx[i + 1] = mapx[i];
            mapy[j + 1] = mapy[j] + 1;
            i++;
            j++;
            printHead(i,1);
        }
        else if (stmap[mapx[i]][mapy[j] - 1] == road || stmap[mapx[i]][mapy[j] - 1] == jinbi || stmap[mapx[i]][mapy[j] - 1] == chu) {
            if (stmap[mapx[i]][mapy[j] - 1] == chu) {
                break;
            }
            stmap[mapx[i]][mapy[j] - 1] = 10;
            mapx[i + 1] = mapx[i];
            mapy[j + 1] = mapy[j] - 1;
            i++;
            j++;
            printHead(i,1);
        }
        else {
            printHead(i, 2);
            i--;
            j--;
        }
    }
    
    return i;
}

//模式设置
int modeset()
{
    Hide();
    GotoXY(40, 10);
    printf("限时模式     1");
    GotoXY(40, 12);
    printf("自走模式     2");
    GotoXY(40, 14);
    printf("无尽模式     3");
    GotoXY(40, 16);
    printf("战神模式     4");
    GotoXY(40, 18);
    printf("彩蛋****     5");
    GotoXY(40, 20);
    switch (mode)
    {
    case 1: printf("当前模式为：  限时模式"); break;
    case 2: printf("当前模式为：  自走模式"); break;
    case 3: printf("当前模式为：  无尽模式"); break;
    case 4: printf("当前模式为：  战神模式"); break;
    case 5: printf("当前模式为：  菜单****（玩得开心哦！）"); break;
    }
    GotoXY(45, 22);
    printf("按其他任意键返回上级菜单");
    char ch;
    ch = _getch();
    switch (ch)
    {
    case '1': mode = 1; break;
    case '2': mode = 2; break;
    case '3': mode = 3; break;
    case '4': mode = 4; break;
    case '5':
        mode = 5;
        width = 54;
        height = 54;
        monster = 10;
        rmb = 10;
        difficult = 6;
        break;
    }
    system("cls");  //清空当前页面
    return mode;
}

//生命值设置
int lifeset()
{
    Hide();
    GotoXY(40, 14);
    printf("输入你想要的生命值 1 — 9 (为了较好游戏体验，建议生命值3-5之间)");
    GotoXY(40, 16);
    printf("当前生命值为：  %d", life);
    GotoXY(45, 18);
    printf("按其他任意键返回上级菜单      ");
    char ch;
    ch = _getch();
    switch (ch)
    {
    case '1': Life = 1; break;
    case '2': Life = 2; break;
    case '3': Life = 3; break;
    case '4': Life = 4; break;
    case '5': Life = 5; break;
    case '6': Life = 6; break;
    case '7': Life = 7; break;
    case '8': Life = 8; break;
    case '9': Life = 9; break;
    }
    life = Life;
    return life;
}

//商店设置
int shopset()
{
    Hide();
    GotoXY(40, 12);
    printf("商店开启请输入 1");
    GotoXY(40, 14);
    printf("商店关闭请输入 0");
    GotoXY(40, 16);
    switch (shop)
    {
    case 1:printf("当前商店处于   开启状态"); break;
    case 0:printf("当前商店处于   关闭状态"); break;
    }
    GotoXY(45, 18);
    printf("按任意键返回上级菜单      ");
    char ch;
    ch = _getch();
    switch (ch)
    {
    case '1': shop = 1; break;
    case '0': shop = 0; break;
    }
    return shop;
}

//开始游戏
int Start()
{
    InitMap();
    //响应键盘的操作
    if (mode == 5) {
        monster = 10;
        rmb = 10;
        difficult = 6;
    }
    while (Movepeople());
    if (mode == 5) {
        monster = 3;
        rmb = 0;
    }
    return 0;
}

//游戏暂停按钮
int Suspend()
{
    system("cls");
    GotoXY(43, 14);
    printf(GREEN"游戏已暂停，按 0 返回主菜单"NONE);
    GotoXY(43, 18);
    printf(GREEN"按其他任意键继续游戏！"NONE);
    char ch;
    int result = 1;
    ch = _getch();
    switch (ch)
    {
    case '0':
        return 0;
    default :
        return 1;
    }

}

//移动人物
int Movepeople()
{
    int lag = 0;
    if (mode != 2) { //表示当前不是自动走的模式
        if (eatpeople == 0) {
            lose();
            return 0;
        }
        Hide();
        if (_kbhit()) {
            direction = _getch();
            switch (direction)
            {
            case UP:
                now_Dir = direction;
                lag = 1;
                break;
            case DOWN:
                now_Dir = direction;
                lag = 1;
                break;
            case RIGHT:
                now_Dir = direction;
                lag = 1;
                break;
            case LEFT:
                now_Dir = direction;
                lag = 1;
                break;
            case SHOOT:
                if (gun) {
                    shoot();
                    Remap();
                }
                break;
            case KILL:
                if (knife) {
                    kill();
                }
                break;
            case 'p':
                if (shop) {
                    Shop();
                    Remap();
                }
                break;
            case ESC:
                if (Suspend()) {
                    Remap();
                    break;
                }
                else {
                    return 0;
                }
                
            }

            GotoXY(people.x * 2 - 2, people.y - 1);
            printf("  ");
            peoplenext.x = people.x;
            peoplenext.y = people.y;
            if (lag) {
                switch (now_Dir) //进行移动
                {
                case UP:peoplenext.y--; lag = 0; break; //上移
                case DOWN:peoplenext.y++; lag = 0; break; //下移
                case LEFT:peoplenext.x--; lag = 0; break; //左移
                case RIGHT:peoplenext.x++; lag = 0; break; //右移
                }
            }
            if (mode == 4) {
                people.x = peoplenext.x;
                people.y = peoplenext.y;
            }
            else {
                if ((iswall(peoplenext.x, peoplenext.y) != wall) && peoplenext.y >= 2) { //如果是墙的处理
                    people.x = peoplenext.x;
                    people.y = peoplenext.y;
                }
                else {
                    peoplenext.x = people.x;
                    peoplenext.y = people.y;
                }
                if (iswall(people.x, people.y) == jinbi) {  //碰到金币时候的处理
                    map[people.x][people.y] = road;
                    rmb++;
                    ztlan();
                    music6q();
                    music6q();
                    music6q();
                }
                else if (iswall(people.x, people.y) == guaishou) { //碰到怪兽时候的处理
                    if (life > 1) {
                        life--;
                        GotoXY(people.x * 2 - 2, people.y - 1);
                        printf("怪");
                        people.x = 2;
                        people.y = 2;
                        GotoXY(people.x * 2 - 2, people.y - 1);
                        printf(WHITE"〇"NONE);
                        ztlan();
                        d5music();
                        d5music();
                        d1music();
                    }
                    else {
                        lose();
                        return 0;
                    }
                }
                else if (iswall(people.x, people.y) == chu) {
                    if (mode == 3) {
                        cgn++;
                        if (difficult < 6) {
                            difficult++;
                        }
                        win();
                        return 0;
                    }
                    else {
                        win();
                        return 0;
                    }
                }
            }
            GotoXY(people.x * 2 - 2, people.y - 1);
            printf(WHITE"〇"NONE);

        }

        Sleep(100);
        if (mode == 1) {
            TIME = TIME - 100;
            times = TIME / 1000;
            if (TIME < 0) {
                lose();
                return 0;
            }
            GotoXY(2 * width + 8, 3);
            Hide();
            printf("剩余时间为： %d 秒   ", times);
            
        }
       cycle++;
            if (cycle  == 5) {
                eatpeople = Movemonster();
                cycle = 0;
            } 
    }
    else { //自动走模式
        bufa = fdmap();
        writeFile(bufa);//写入文件

        for (int m = 1; m <= bufa; m++) {
            GotoXY(mapx[m]*2 - 2, mapy[m] - 1);
            printf(WHITE"〇"NONE);
            Sleep(200);
            GotoXY(mapx[m]*2 - 2, mapy[m] - 1);
            printf("  ");
        }
        win();
        return 0;
    }
    return 1;
   

}

//写路径到文件中
void writeFile(rodeSize) {
    FILE* fp;
    errno_t err;
    err = fopen_s(&fp, "roude.txt", "w+");
    if (err != 0)
    {
        printf("打开失败");
    }
    for (int i = 1; i < rodeSize; i++) {
        fprintf(fp, "(%d,%d)->", mapy[i],mapx[i]);
    }
    fclose(fp);

}

//射击函数
int shoot()
{
    int x = people.x;
    int y = people.y;
    switch (now_Dir)
    {
    case 'w':
        while (map[x][y - 1] == road || map[x][y - 1] == guaishou) {
            y--;

            GotoXY(2 * x - 2, y - 1);
            if (map[x][y] == guaishou) {
                printf("＃");
                map[x][y] = jinbi;
                Sleep(200);
                Reroad();
                return 0;
            }
            else {
                printf("·");
            }
            Sleep(60);
            
            
        }
        break;
    
    case 'd':
        while (map[x + 1][y] == road || map[x + 1][y] == guaishou) {
            x++;

            GotoXY(2 * x - 2, y - 1);
            if (map[x][y] == guaishou) {
                printf("＃");
                map[x][y] = jinbi;
                Sleep(200);
                Reroad();
                return 0;
            }
            else {
                printf("·");
            }
            Sleep(60);
            
        }
        break;
    case 's':
        while (map[x][y + 1] == road || map[x][y + 1] == guaishou) {
            y++;
 
            GotoXY(2 * x - 2, y - 1);
            if (map[x][y] == guaishou) {
                printf("＃");
                map[x][y] = jinbi;
                Sleep(200);
                Reroad();
                return 0;
            }
            else {
                printf("·");
            }
            Sleep(60);
            
        }
        break;
    case 'a':
        while (map[x - 1][y] == road || map[x - 1][y] == guaishou) {
            x--;

            GotoXY(2 * x - 2, y - 1);
            if (map[x][y] == guaishou) {
                printf("＃");
                map[x][y] = jinbi;
                Sleep(200);
                Reroad();
                return 0;
            }
            else {
                printf("·");
            }
            Sleep(60);
            
        }
        break;
    }
    Remap();

}

//kill(瑞士军刀)函数
int kill()
{
    int x = people.x;
    int y = people.y;
    switch (now_Dir)
    {
    case 'w':
        if (map[x][y - 1] == road || map[x][y - 1] == guaishou) {
            y--;
            GotoXY(2 * x - 2, y - 1);
            if (map[x][y] == guaishou) {
                printf("＃");
                map[x][y] = jinbi;
                
            }
            else {
                printf("｜");
            }
        }
        if (map[x][y - 1] == road || map[x][y - 1] == guaishou) {
            y--;
            GotoXY(2 * x - 2, y - 1);
            if (map[x][y] == guaishou) {
                printf("＃");
                map[x][y] = jinbi;

            }
            else {
                printf("｜");
            }
        }
        Sleep(200);
        Remap();
        break;

    case 'd':
        if (map[x + 1][y] == road || map[x + 1][y] == guaishou) {
            x++;
            GotoXY(2 * x - 2, y - 1);
            if (map[x][y] == guaishou) {
                printf("＃");
                map[x][y] = jinbi;
                
            }
            else {
                printf("－");
            }
        }
        if (map[x + 1][y] == road || map[x + 1][y] == guaishou) {
            x++;
            GotoXY(2 * x - 2, y - 1);
            if (map[x][y] == guaishou) {
                printf("＃");
                map[x][y] = jinbi;

            }
            else {
                printf("－");
            }
        }
        Sleep(200);
        Remap();
        break;
    case 's':
        if (map[x][y + 1] == road || map[x][y + 1] == guaishou) {
            y++;
            GotoXY(2 * x - 2, y - 1);
            if (map[x][y] == guaishou) {
                printf("＃");
                map[x][y] = jinbi;

            }
            else {
                printf("｜");
            }
        }
        if (map[x][y + 1] == road || map[x][y + 1] == guaishou) {
            y++;
            GotoXY(2 * x - 2, y - 1);
            if (map[x][y] == guaishou) {
                printf("＃");
                map[x][y] = jinbi;

            }
            else {
                printf("｜");
            }
        }
        Sleep(200);
        Remap();
        break;
    case 'a':
        if (map[x - 1][y] == road || map[x - 1][y] == guaishou) {
            x--;
            GotoXY(2 * x - 2, y - 1);
            if (map[x][y] == guaishou) {
                printf("＃");
                map[x][y] = jinbi;

            }
            else {
                printf("－");
            }
        }
        if (map[x - 1][y] == road || map[x - 1][y] == guaishou) {
            x--;
            GotoXY(2 * x - 2, y - 1);
            if (map[x][y] == guaishou) {
                printf("＃");
                map[x][y] = jinbi;

            }
            else {
                printf("－");
            }
        }
        Sleep(200);
    }
    Remap();
}

//移动怪物
int Movemonster()
{
    int fangxiang;       //用于解决怪兽的方向
    int flag = 1;

    for (int i = 1; i <= width; i++) {
        for (int j = 1; j <= height; j++) {
            if (map[i][j] == guaishou) {
                while (flag) {
                    fangxiang =  rand() % 4;
                    switch (fangxiang)
                    {
                    case 0:
                        if (map[i + 1][j] == road && mapp[i][j] != Zhulu) {
                            map[i + 1][j] = guaishou1;
                            map[i][j] = road;
                            GotoXY(i * 2 - 2, j - 1);
                            printf("  ");
                            flag = 0;
                        }
                        else if (mapp[i][j] == Zhulu) {
                            reroad(i, j);
                            flag = 0;
                        }
                        
                        break;
                    case 1:
                        if (map[i - 1][j] == road && mapp[i][j] != Zhulu) {
                            map[i - 1][j] = guaishou1;
                            map[i][j] = road;
                            GotoXY(i * 2 - 2, j - 1);
                            printf("  ");
                            flag = 0;
                        }
                        else if (mapp[i][j] == Zhulu) {
                            reroad(i, j);
                            flag = 0;
                        }
                        
                        break;
                    case 2:
                        if (map[i][j + 1] == road && mapp[i][j] != Zhulu) {
                            map[i][j + 1] = guaishou1;
                            map[i][j] = road;
                            GotoXY(i * 2 - 2, j - 1);
                            printf("  ");
                            flag = 0;
                        }
                        else if (mapp[i][j] == Zhulu) {
                            reroad(i, j);
                            flag = 0;
                        }
                        
                        break;
                    case 3:
                        if (map[i][j - 1] == road && mapp[i][j] != Zhulu) {
                            map[i][j - 1] = guaishou1;
                            map[i][j] = road;
                            GotoXY(i * 2 - 2, j - 1);
                            printf("  ");
                            flag = 0;
                        }
                        else if (mapp[i][j] == Zhulu) {
                            reroad(i, j);
                            flag = 0;
                        }
                        break;
                    }
                }
                flag = 1;
            }
        }
    }
    for (int i = 1; i <= width; i++) {
        for (int j = 1; j <= height; j++) {
            if (map[i][j] == guaishou1) {
                map[i][j] = guaishou;
                if (people.x == i && people.y == j) {
                    if (life > 1) {
                        life--;
                        GotoXY(people.x * 2 - 2, people.y - 1);
                        printf("怪");
                        people.x = 2;
                        people.y = 2;
                        GotoXY(people.x * 2 - 2, people.y - 1);
                        printf(WHITE"〇"NONE);
                        ztlan();
                        d5music();
                        d5music();
                        d1music();
                    }
                    else {
                        return 0;
                    }
                }
                GotoXY(i * 2 - 2, j - 1);
                printf(BLUE"怪"NONE);

            }
        }
    }
    return 1;
}

//怪物走到主路原路返回
int reroad(int i, int j)
{
    int flag = 1;  //找到返回的方向为0 没有找到为1
    while (flag) {
        if (map[i + 1][j] == road && mapp[i + 1][j] != Zhulu ) {
            map[i + 1][j] = guaishou1;
            map[i][j] = road;
            GotoXY(i * 2 - 2, j - 1);
            printf("  ");
            flag = 0;
        }
        else if (map[i - 1][j] == road && mapp[i - 1][j] != Zhulu) {
            map[i - 1][j] = guaishou1;
            map[i][j] = road;
            GotoXY(i * 2 - 2, j - 1);
            printf("  ");
            flag = 0;
        }
        else if (map[i][j + 1] == road && mapp[i][j + 1] != Zhulu) {
            map[i][j + 1] = guaishou1;
            map[i][j] = road;
            GotoXY(i * 2 - 2, j - 1);
            printf("  ");
            flag = 0;
        }
        else if (map[i][j - 1] == road && mapp[i][j - 1] != Zhulu) {
            map[i][j - 1] = guaishou1;
            map[i][j] = road;
            GotoXY(i * 2 - 2, j - 1);
            printf("  ");
            flag = 0;
        }
       
    }
    return 0;

}

//游戏失败界面
int lose()
{
    system("cls");  //清空当前页面

    GotoXY(43, 12);   //定位光标的位置
    printf(RED"YOU LOSE !!!");
    GotoXY(43, 14);
    printf("你真菜！！！");
    GotoXY(43, 16);
    printf("游戏结束");
    if (mode == 3) {
        printf("你成功闯过 %d 关", cgn);
    }
    GotoXY(43, 18);
    printf("关闭游戏请点击右上角 X");
    GotoXY(43, 22);
    printf("继续游戏按0回到主菜单栏目"NONE);
    music3();
    music3();
    music2();
    music2();
    d5music();
    Hide();    //隐藏光标
    char ch;
    int result = 1;
    ch = _getch();
    while (ch != '0') {
        ch = _getch();
    }
    life = Life;    //重置生命数量
    eatpeople = 1;  //重置人被吃状态为1
    system("cls");  //清空当前页面
    return 0;
}

//游戏胜利界面
int win()
{
    system("cls");  //清空当前页面

    GotoXY(43, 12);   //定位光标的位置
    printf(BLUE"YOU WIN !!!");
    GotoXY(43, 14);
    printf("你真棒！！！");
    GotoXY(43, 16);
    winmusic();
    if (mode == 3) {
        printf("你已经闯过 %d 关", cgn);
    }
    else {
        printf("游戏结束");
    }
    GotoXY(43, 18);
    printf("关闭游戏请点击右上角 X"NONE);
    GotoXY(43, 22);
    if (mode != 3) {
        printf(BLUE"继续游戏按任意键回到主菜单栏目"NONE);
        life = Life;    //重置生命数量
    }
    else {
        printf(BLUE"继续游戏按任意键开启下一关卡"NONE);
    }
    Hide();    //隐藏光标
    char ch;
    int result = 1;
    ch = _getch();
    system("cls");  //清空当前页面
    if (mode == 3) {
        Start();
    }
    else {
        return 0;
    }
}

//右侧状态栏更新
int ztlan()
{
    GotoXY(2*width + 8, 5);
    printf("当前生命值： ");
    for (int i = 1; i <= life; i++) {
        printf("●");
    }
    for (int i = life; i <= 10; i++) {
        printf("  ");
    }
    GotoXY(2 * width + 8, 7);
    printf("当前金币 ￥：  %d", rmb);
    GotoXY(2 * width + 8, 9);
    printf("当前模式为： ");
    switch (mode)
    {
    case 1:
        printf("限时模式");
        break;
    case 2:
        printf("自走模式");
            break;
    case 3:
        printf("无尽模式");
            break;
    case 4:
        printf("战神模式");
            break;
    }
    GotoXY(2 * width + 8, 11);
    printf("当前已装备  ");
    if (gun)
    {
        printf("  冲锋枪");
    }
    if (knife)
    {
        printf("  瑞士军刀");
    }
    GotoXY(2 * width + 8, 13);
    if (mode == 3) {
        printf("你已经闯过 %d 关", cgn);
    }

}

//商店代码
int Shop()
{
    system("cls");
    GotoXY(40, 14);
    printf("购买生命2￥        请输入 1");
    GotoXY(40, 16);
    printf("购买瑞士军刀10￥   请输入 2");
    GotoXY(40, 18);
    printf("购买冲锋枪20￥     请输入 3");
    GotoXY(40, 20);
    printf("当前生命值 %d", life);
    GotoXY(40, 22);
    printf("当前金额 %d", rmb);
    GotoXY(40, 24);
    printf("当前已装备  ");
    if (gun)
    {
        printf("  冲锋枪");
    }
    if (knife)
    {
        printf("  瑞士军刀");
    }
    GotoXY(45, 26);
    printf("按其他任意键返回游戏");
    char ch;
    ch = _getch();
    switch (ch)
    {
    case '1':
        if (rmb < 2) {
            lackrmb();
        }
        else {
            rmb -= 2;
            life++;
        }
        break;
    case '2':
        if (knife) {
            albuy();
        }
        else if (rmb < 10){
            lackrmb();
        }
        else {
            knife = 1;
            rmb -= 10;
        }
        break;
    case '3':
        if (gun) {
            albuy();
        }
        else if (rmb < 10) {
            lackrmb();
        }
        else {
            gun = 1;
            rmb -= 20;
        }
        break;
    default:
        return 0;
    }
    Shop();

}

//金币不足界面
int lackrmb()
{
    system("cls");
    GotoXY(40, 12);
    printf("金币不足！！！");
    GotoXY(40, 13);
    printf("按任意建返回商店！");
    char ch;
    ch = _getch();
    return 0;
}

//已经购买界面
int albuy()
{
    system("cls");
    GotoXY(40, 12);
    printf("该装备已购买！");
    GotoXY(40, 13);
    printf("按任意建返回商店！");
    char ch;
    ch = _getch();
    return 0;
}

//设置帮助页面
void Help()
{
    GotoXY(40, 10);
    printf(OBLUE"w 上          按 p 进入商店模式");
    GotoXY(40, 12);
    printf("s 下          有瑞士军刀时按 k 可以挥剑");
    GotoXY(40, 14);
    printf("a 左          有冲锋枪时按 j 可以开枪");
    GotoXY(40, 16);
    printf("d 右          游戏进行时按 0 可以暂停");
    GotoXY(40, 18);
    printf("用尽快的方式躲避怪兽！走出迷宫！加油！胜利属于你！");
    GotoXY(45, 20);
    printf("按任意键返回上级菜单      "NONE);
    char ch = _getch();
    system("cls");
}

//关于信息界面
void About()
{
    GotoXY(43, 12);
    printf(OPURPLE"数据结构大作业之走迷宫");
    GotoXY(43, 14);
    printf("智慧走迷宫小游戏");
    GotoXY(43, 16);
    printf("制作人：虞程龙 ");
    GotoXY(43, 18);
    printf("按任意键返回上级菜单"NONE);
    heavensong();
    Hide();    //隐藏光标
    char ch = _getch();
    system("cls");
}

//随机数
void create(int x, int y) //随机生成迷宫
{
    int c[4][2] = { 0,1,1,0,0,-1,-1,0 }; //四个方向
    int i, j, t;
    //将方向打乱
    for (i = 0; i < 4; i++)
    {
        j = rand() % 4;
        t = c[i][0]; c[i][0] = c[j][0]; c[j][0] = t;
        t = c[i][1]; c[i][1] = c[j][1]; c[j][1] = t;
    }
    map[x][y] = road;
    for (i = 0; i < 4; i++) {
        if (map[x + 2 * c[i][0]][y + 2 * c[i][1]] == wall)
        {
            map[x + c[i][0]][y + c[i][1]] = road;
            create(x + 2 * c[i][0], y + 2 * c[i][1]);
        }
    }
}

//地图初始化
void InitMap()
{
    if (mode == 1) {
        TIME = 15 * 1000 + difficult * 40000;
    }
    Hide();
    if (mode == 5) {
        map2();
    }
    else {
        int i, j;
        for (i = 0; i <= height; i++) {
            for (j = 0; j <= width; j++) {
                if (i == 0 || i == height || j == 0 || j == width) {  //初始化迷宫
                    map[i][j] = road;
                }
                else {
                    map[i][j] = wall;
                }
            }
        }

        create(2 * (rand() % ((height - 1) / 2) + 1), 2 * (rand() % ((width - 1) / 2) + 1)); //从随机一个点开始生成迷宫，该点行列都为偶数
        for (i = 0; i <= height; i++) //边界处理
        {
            map[1][i] = wall;
            map[width][i] = wall;
        }

        for (j = 0; j <= width; j++) //边界处理
        {
            map[j][1] = wall;
            map[j][height] = wall;
        }
        map[1][2] = 2; //给定入口
        map[width][height - 1] = 3; //给定出口
        for (i = 1; i <= height; i++)
            for (j = 1; j <= width; j++) {
                GotoXY(2 * j - 2, i - 1);
                switch (map[j][i])
                {
                case 2:
                    printf(GREEN"入"); break; //画入口
                case 3:
                    printf(RED"出"); break; //画出口
                case wall:
                    printf(YELLOW"██"NONE); break; //画墙
                case road:
                    printf("  "); break; //画路
                }
            }
    }

    people.x = 2;
    people.y = 2;
    GotoXY(people.x * 2 - 2, people.y - 1);
    printf(WHITE"〇"NONE);
    ptmonster(); //打印怪兽
    ptmoney();   //打印金币
    ztlan();     //右侧状态栏打印


    //下面用于怪兽自动走
    if (mode != 5 && mode != 2) {
        bufa = fdmap();

        for (int i = 1; i <= width; i++) {
            for (int j = 1; j <= height; j++) {
                mapp[i][j] = 0;
            }
        }
        while (bufa > 0) {
            mapp[mapx[bufa]][mapy[bufa]] = Zhulu;
            bufa--;
        }
    }
    else {
        Remap();
    }
}

//重新绘制地图
void Remap()
{
    system("cls");
    for (int i = 1; i <= height; i++)
        for (int j = 1; j <= width; j++) {
            GotoXY(2 * j - 2, i - 1);
            switch (map[j][i])
            {
            case 2:
                printf(GREEN"入"NONE); break; //画入口
            case 3:
                printf(RED"出"NONE); break; //画出口
            case wall:
                printf(YELLOW"██"NONE); break; //画墙
            case road:
                printf("  "); break; //画路
            case jinbi:
                printf(PURPLE"￥"NONE); break; //画金币
            case guaishou:
                printf(BLUE"怪"NONE); break; //画怪兽
            }
        }
    GotoXY(people.x * 2 - 2, people.y - 1);
    printf(WHITE"〇"NONE);
    ztlan();
}

//重新绘制头结点（重新绘制当前的位置〇,用于自动走）
void printHead(int i,int j) {
    if (mode == 2) {
        if (j == 1) {
            if (i == 1) {
                GotoXY(mapx[i] * 2 - 2, mapy[i] - 1);
                printf(WHITE"〇"NONE);
                Sleep(200);
            }
            else {
                GotoXY(mapx[i] * 2 - 2, mapy[i] - 1);
                printf(WHITE"〇"NONE);
                GotoXY(mapx[i - 1] * 2 - 2, mapy[i - 1] - 1);
                printf("·");
                Sleep(200);
            }
        }
        else {
            GotoXY(mapx[i] * 2 - 2, mapy[i] - 1);
            printf("  ");
            GotoXY(mapx[i - 1] * 2 - 2, mapy[i - 1] - 1);
            printf(WHITE"〇"NONE);
            Sleep(200);
        }
    }
   
    GotoXY(0, height+1);
    printf(OBLUE"路线记录如下："NONE);
    GotoXY(0, height+3);
    for (int m = 1; m <= i; m++) {
        printf("(%d,%d)->",mapy[m],mapx[m]);
    }
    for (int m = 1; m <= 100; m++) {
        printf("        ");
    }
}

//重新打印路
void Reroad()
{
    for (int i = 1; i <= height; i++)
        for (int j = 1; j <= width; j++) {
            GotoXY(2 * j - 2, i - 1);
            switch (map[j][i])
            {
            case road:
                printf("  "); break; //画路
            }
        }
}

//打印怪兽
void ptmonster()
{
    int ci = 0;
    while (ci < monster) {
        jshi.x = rand() % (width  - 2) + 2;
        jshi.y = rand() % (height - 2) + 2;
        if (iswall(jshi.x, jshi.y) == wall) {
            map[jshi.x][jshi.y] = guaishou;
            GotoXY(jshi.x * 2 - 2, jshi.y - 1);
            printf(BLUE"怪"NONE);
            ci++;
        }
    }
}

//打印金币
void ptmoney()
{
    if (!shop) {
        return 0;
    }
    else {
        int ci = 0;
        while (ci < difficult * 3) {
            money.x = rand() % (width - 1) + 2;
            money.y = rand() % (height - 1) + 2;
            if (iswall(money.x, money.y) == road) {
                map[money.x][money.y] = jinbi;
                GotoXY(money.x * 2 - 2, money.y - 1);
                printf(PURPLE"￥"NONE);
                ci++;
            }
        }
    }
}

//判断是否是墙
int iswall(int x, int y)
{
    if (map[x][y] == wall) {
        return wall;
    }
    else if(map[x][y] == road){
        return road;
    }
    else if (map[x][y] == 2 && y >= 1 && y < height && x >= 2 && x < width * 2 - 2) {
        return 2;
    }
    else if (map[x][y] == chu) {
        return chu;
    }
    else if (map[x][y] == jinbi) {
        return jinbi;
    }
    else if (map[x][y] == guaishou) {
        return guaishou;
    }
    else {
        return 4;
    }
}

//彩蛋处理函数
int Chuli(x, y) {
    map[x + 1][y + 1] = wall;
    GotoXY(2 * x, y);
}