#include "Mi.h"
void prt()
{
    printf("�~");
}

void map2()
{
    for (int i = 1; i <= 54; i++) {
        for (int j = 1; j <= 54; j++) {
            map[i][j] = road;
        }
    }
    Hide();
    for (int i = 0; i <= 53; i++)
    {
        Chuli(0, i);
        prt();
    }
    for (int i = 2; i <= 53; i++)
    {
        Chuli(i, 0);
        prt();
    }
    for (int i = 0; i <= 53; i++)
    {
        Chuli(53, i);
        prt();
    }
    for (int i = 0; i <= 53; i++)
    {
        Chuli(i, 53);
        prt();
    }
    for (int i = 2; i <= 21; i++)
    {
        Chuli(i, 1);
        prt();
    }
    Chuli(23, 1);
    prt();
    Chuli(24, 2);
    prt();
    Chuli(1, 5);
    prt();
    Chuli(24, 5);
    prt();
    Chuli(23, 6);
    prt();
    Chuli(37, 2);
    prt();
    Chuli(1, 16);
    prt();
    Chuli(43, 5);
    prt();
    Chuli(38, 7);
    prt();
    Chuli(43, 9);
    prt();
    Chuli(9, 7);
    prt();
    Chuli(15, 11);
    prt();
    for (int i = 34; i <= 44; i++)
    {
        Chuli(i, 1);
        prt();
    }
    for (int i = 3; i <= 19; i++)
    {
        Chuli(i, 5);
        prt();
    }
    for (int i = 24; i <= 25; i++)
    {
        Chuli(i, 5);
        prt();
    }
    for (int i = 2; i <= 4; i++)
    {
        Chuli(15, i);
        prt();
    }
    for (int i = 2; i <= 3; i++)
    {
        Chuli(17, i);
        prt();
    }
    for (int i = 3; i <= 4; i++)
    {
        Chuli(19, i);
        prt();
    }
    for (int i = 2; i <= 5; i++)
    {
        Chuli(21, i);
        prt();
    }
    for (int i = 2; i <= 4; i++)
    {
        Chuli(10, i);
        prt();
    }
    for (int i = 6; i <= 23; i++)
    {
        Chuli(10, i);
        prt();
    }
    for (int i = 3; i <= 27; i++)
    {
        Chuli(25, i);
        prt();
    }
    for (int i = 6; i <= 23; i++)
    {
        Chuli(18, i);
        prt();
    }
    for (int i = 2; i <= 12; i++)
    {
        Chuli(34, i);
        prt();
    }
    for (int i = 2; i <= 12; i++)
    {
        Chuli(44, i);
        prt();
    }
    for (int i = 8; i <= 9; i++)
    {
        Chuli(i, 8);
        prt();
    }
    for (int i = 7; i <= 8; i++)
    {
        Chuli(i, 9);
        prt();
    }
    for (int i = 6; i <= 7; i++)
    {
        Chuli(i, 10);
        prt();
    }
    for (int i = 5; i <= 6; i++)
    {
        Chuli(i, 11);
        prt();
    }
    for (int i = 4; i <= 5; i++)
    {
        Chuli(i, 12);
        prt();
    }
    for (int i = 3; i <= 4; i++)
    {
        Chuli(i, 13);
        prt();
    }
    for (int i = 1; i <= 2; i++)
    {
        Chuli(i, 15);
        prt();
    }
    for (int i = 15; i <= 17; i++)
    {
        Chuli(i, 8);
        prt();
    }
    for (int i = 19; i <= 21; i++)
    {
        Chuli(i, 8);
        prt();
    }
    for (int i = 15; i <= 20; i++)
    {
        Chuli(i, 12);
        prt();
    }
    for (int i = 7; i <= 8; i++)
    {
        Chuli(11, i);
        prt();
    }
    for (int i = 8; i <= 9; i++)
    {
        Chuli(12, i);
        prt();
    }
    for (int i = 9; i <= 10; i++)
    {
        Chuli(13, i);
        prt();
    }
    for (int i = 10; i <= 11; i++)
    {
        Chuli(14, i);
        prt();
    }
    for (int i = 26; i <= 33; i++)
    {
        Chuli(i, 12);
        prt();
    }
    for (int i = 1; i <= 4; i++)
    {
        Chuli(i, 24);
        prt();
    }
    for (int i = 6; i <= 21; i++)
    {
        Chuli(i, 24);
        prt();
    }
    for (int i = 10; i <= 32; i++)
    {
        Chuli(i, 28);
        prt();
    }
    for (int i = 32; i <= 44; i++)
    {
        Chuli(i, 14);
        prt();
    }
    for (int i = 45; i <= 52; i++)
    {
        Chuli(i, 12);
        prt();
    }
    for (int i = 38; i <= 42; i++)
    {
        Chuli(i, 10);
        prt();
    }
    for (int i = 35; i <= 41; i++)
    {
        Chuli(i, 6);
        prt();
    }
    for (int i = 35; i <= 37; i++)
    {
        Chuli(i, 4);
        prt();
    }
    for (int i = 46; i <= 52; i++)
    {
        Chuli(i, 28);
        prt();
    }
    for (int i = 5; i <= 25; i++)
    {
        Chuli(i, 37);
        prt();
    }
    for (int i = 27; i <= 52; i++)
    {
        Chuli(i, 37);
        prt();
    }
    for (int i = 8; i <= 17; i++)
    {
        Chuli(i, 31);
        prt();
    }
    for (int i = 19; i <= 22; i++)
    {
        Chuli(i, 31);
        prt();
    }
    for (int i = 35; i <= 36; i++)
    {
        Chuli(i, 11);
        prt();
    }
    for (int i = 39; i <= 40; i++)
    {
        Chuli(i, 41);
        prt();
    }
    for (int i = 45; i <= 49; i++)
    {
        Chuli(i, 41);
        prt();
    }
    for (int i = 51; i <= 52; i++)
    {
        Chuli(i, 41);
        prt();
    }
    for (int i = 42; i <= 43; i++)
    {
        Chuli(i, 42);
        prt();
    }
    for (int i = 42; i <= 45; i++)
    {
        Chuli(i, 45);
        prt();
    }
    for (int i = 47; i <= 50; i++)
    {
        Chuli(i, 44);
        prt();
    }
    for (int i = 39; i <= 42; i++)
    {
        Chuli(i, 47);
        prt();
    }
    for (int i = 39; i <= 44; i++)
    {
        Chuli(i, 49);
        prt();
    }
    for (int i = 49; i <= 52; i++)
    {
        Chuli(i, 49);
        prt();
    }
    for (int i = 46; i <= 49; i++)
    {
        Chuli(i, 50);
        prt();
    }
    for (int i = 39; i <= 41; i++)
    {
        Chuli(i, 51);
        prt();
    }
    for (int i = 2; i <= 4; i++)
    {
        Chuli(39, i);
        prt();
    }
    for (int i = 3; i <= 5; i++)
    {
        Chuli(41, i);
        prt();
    }
    for (int i = 8; i <= 9; i++)
    {
        Chuli(36, i);
        prt();
    }
    for (int i = 9; i <= 11; i++)
    {
        Chuli(38, i);
        prt();
    }
    for (int i = 7; i <= 8; i++)
    {
        Chuli(40, i);
        prt();
    }
    for (int i = 38; i <= 47; i++)
    {
        Chuli(17, i);
        prt();
    }
    for (int i = 49; i <= 52; i++)
    {
        Chuli(17, i);
        prt();
    }
    for (int i = 48; i <= 52; i++)
    {
        Chuli(1, i);
        prt();
    }
    for (int i = 45; i <= 48; i++)
    {
        Chuli(2, i);
        prt();
    }
    for (int i = 42; i <= 43; i++)
    {
        Chuli(3, i);
        prt();
    }
    Chuli(3, 45);
    prt();
    for (int i = 39; i <= 42; i++)
    {
        Chuli(4, i);
        prt();
    }
    for (int i = 38; i <= 39; i++)
    {
        Chuli(5, i);
        prt();
    }
    for (int i = 35; i <= 36; i++)
    {
        Chuli(6, i);
        prt();
    }
    for (int i = 32; i <= 33; i++)
    {
        Chuli(8, i);
        prt();
    }
    for (int i = 29; i <= 30; i++)
    {
        Chuli(9, i);
        prt();
    }
    for (int i = 31; i <= 52; i++)
    {
        Chuli(28, i);
        prt();
    }
    for (int i = 21; i <= 25; i++)
    {
        Chuli(39, i);
        prt();
    }
    for (int i = 27; i <= 52; i++)
    {
        Chuli(39, i);
        prt();
    }
    for (int i = 38; i <= 41; i++)
    {
        Chuli(42, i);
        prt();
    }
    for (int i = 38; i <= 39; i++)
    {
        Chuli(45, i);
        prt();
    }
    for (int i = 42; i <= 47; i++)
    {
        Chuli(45, i);
        prt();
    }
    for (int i = 50; i <= 51; i++)
    {
        Chuli(43, i);
        prt();
    }
    for (int i = 39; i <= 40; i++)
    {
        Chuli(47, i);
        prt();
    }
    for (int i = 45; i <= 51; i++)
    {
        Chuli(49, i);
        prt();
    }
    for (int i = 38; i <= 39; i++)
    {
        Chuli(49, i);
        prt();
    }
    for (int i = 29; i <= 31; i++)
    {
        Chuli(i, 45);
        prt();
    }
    for (int i = 19; i <= 20; i++)
    {
        Chuli(i, 35);
        prt();
    }
    Chuli(14, 25);
    prt();
    Chuli(15, 26);
    prt();
    Chuli(16, 27);
    prt();
    Chuli(7, 33);
    prt();
    Chuli(7, 35);
    prt();
    Chuli(18, 34);
    prt();
    Chuli(20, 34);
    prt();
    Chuli(21, 33);
    prt();
    Chuli(22, 32);
    prt();
    Chuli(26, 29);
    prt();
    Chuli(14, 50);
    prt();
    Chuli(15, 51);
    prt();
    Chuli(16, 52);
    prt();
    Chuli(24, 36);
    prt();
    Chuli(25, 35);
    prt();
    Chuli(26, 34);
    prt();
    Chuli(27, 33);
    prt();
    Chuli(33, 15);
    prt();
    Chuli(34, 16);
    prt();
    Chuli(35, 17);
    prt();
    Chuli(36, 18);
    prt();
    Chuli(37, 19);
    prt();
    Chuli(38, 20);
    prt();
    Chuli(40, 22);
    prt();
    Chuli(41, 23);
    prt();
    Chuli(43, 25);
    prt();
    Chuli(44, 26);
    prt();
    Chuli(45, 27);
    prt();
    Chuli(45, 15);
    prt();
    Chuli(44, 16);
    prt();
    Chuli(43, 17);
    prt();
    Chuli(42, 18);
    prt();
    Chuli(41, 19);
    prt();
    Chuli(40, 20);
    prt();
    Chuli(39, 21);
    prt();
    Chuli(38, 22);
    prt();
    Chuli(37, 23);
    prt();
    Chuli(35, 25);
    prt();
    Chuli(34, 26);
    prt();
    Chuli(33, 27);
    prt();
    Chuli(42, 44);
    prt();
    Chuli(48, 42);
    prt();
    Chuli(51, 39);
    prt();
    Chuli(52, 44);
    prt();
    Chuli(51, 46);
    prt();
    Chuli(51, 51);
    prt();
    Chuli(24, 2);
    Chuli(44, 12);
    Chuli(39, 37);
    Chuli(47, 28);
    map[54][48] = chu;
    map[2][1] = ru;
}