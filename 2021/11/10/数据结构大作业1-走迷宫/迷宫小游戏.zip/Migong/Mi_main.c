#include "Mi.h"

int main()
{

    system("title ���Թ�");
    int flag = 1;
    Hide();
    srand((unsigned)time(NULL)); //��ʼ���漴����
    height = HEIGHT + 4 * difficult ;
    width = WIDTH + 4 * difficult ;
    while (flag) {
        system("cls");
        switch (Menu())
        {
        case 1:
            Start();
            break;
        case 2:
            setting();
            break;
        case 3:
            Help();
            break;
        case 4:
            About();
            break;
        case 0:
            flag = 0;
            break;
        }
    }
    return 0;
}