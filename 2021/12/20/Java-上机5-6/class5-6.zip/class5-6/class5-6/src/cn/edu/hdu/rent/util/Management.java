package cn.edu.hdu.rent.util;

import cn.edu.hdu.account.core.IllegalInputException;

public interface Management {
    void add(int type) throws IllegalInputException; //增加汽车
    void delete(int ID); //删除ID对应的汽车
    void update(int ID); //更新ID对应的汽车
    void show(); //显示ID对应的汽车
    int exit(); //退出

}
