package cn.edu.hdu.rent.core;

import cn.edu.hdu.rent.util.CanCarryPeople;

public class Car extends Automobile implements CanCarryPeople  {
    private double peopleCapacity;

    @Override
    public void setPeopleCapacity(double capacity) {
        this.peopleCapacity = capacity;
    }

    @Override
    public double getPeopleCapacity() {
        return this.peopleCapacity;
    }
}
