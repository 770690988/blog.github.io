package cn.edu.hdu.account.core;

public interface AccountFeature {
    public void showMainMenu();
    public void showDetailInfo();
    public void editIncomeInfo();
    public void editSpendInfo();
    public void exitAccount();
}
