package cn.edu.hdu.rent.core;

import cn.edu.hdu.rent.util.CanCarryCargo;
import cn.edu.hdu.rent.util.CanCarryPeople;

public class PickUp extends Automobile implements CanCarryPeople, CanCarryCargo {
    private double peopleCapacity;
    private double cargoCapacity;

    @Override
    public void setPeopleCapacity(double capacity) {
           this.peopleCapacity = capacity;
    }

    @Override
    public double getPeopleCapacity() {
        return this.peopleCapacity;
    }

    @Override
    public void setCargoCapacity(double capacity) {
        this.cargoCapacity = capacity;
    }

    @Override
    public double getCargoCapacity() {
        return this.cargoCapacity;
    }
}
