package cn.edu.hdu.rent.util;

public class RenSysGlobalVar {
}
