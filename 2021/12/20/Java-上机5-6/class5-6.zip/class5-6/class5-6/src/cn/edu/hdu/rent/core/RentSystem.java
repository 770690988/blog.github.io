package cn.edu.hdu.rent.core;

import cn.edu.hdu.rent.util.RentSysConst;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class RentSystem {
    private HashMap<Integer, HashMap<Automobile,Integer>> orders = new HashMap<Integer, HashMap<Automobile,Integer>>(); //汽车品牌
    private int ID = 1;  //订单ID

    public void showMenu(){
        System.out.println("=========你可以租车的类型及其价目表========");
        Iterator<Map.Entry<Integer, Automobile>> iterator = RentSysConst.AUTO_LIST.entrySet().iterator();
        System.out.printf("%-10s\t%-10s\t%-10s\t%-10s\t%-10s%n","序号","汽车名称","租金","载客量","载货量");
        while (iterator.hasNext()){
            Map.Entry<Integer, Automobile> entry = iterator.next();
            if(entry.getValue() instanceof Car){
                Car car = (Car)entry.getValue();
                System.out.printf("%-10s\t%-15s\t%-10s\t%-15s\t%-10s%n",entry.getKey(),car.getBrand(),car.getPrice(),car.getPeopleCapacity(),"0.0");
            }
            else if(entry.getValue() instanceof Truck){
                Truck truck = (Truck) entry.getValue();
                System.out.printf("%-10s\t%-15s\t%-10s\t%-15s\t%-10s%n",entry.getKey(),truck.getBrand(),truck.getPrice(),"0.0",truck.getCargoCapacity());
            }
            else if(entry.getValue() instanceof PickUp){
                PickUp pickUp = (PickUp) entry.getValue();
                System.out.printf("%-10s\t%-15s\t%-10s\t%-15s\t%-10s%n",entry.getKey(),pickUp.getBrand(),pickUp.getPrice(),pickUp.getPeopleCapacity(),pickUp.getCargoCapacity());
            }
        }
    } //显示租车系统界面

    public void chooseAutomobiles(){
        int id = 0;
        int days = 0;
        int flag = 1;

        while (flag == 1) {
            HashMap<Automobile,Integer> hashMap = new HashMap<Automobile,Integer>();
            while (true) {
                System.out.println("请输入要租的汽车ID（-1退出）");
                id = RentSysConst.INPUT.nextInt();
                if (id == -1) break;

                System.out.println("请输入要租的天数：");
                days = RentSysConst.INPUT.nextInt();
                hashMap.put(RentSysConst.AUTO_LIST.get(id), days);

            }
            orders.put(ID, hashMap);
            ID++;
            flag = showOrder();
        }
    }//选择车辆

    public int showOrder(){
        int flag = 0;
        System.out.println("你的订单");
        Iterator<Map.Entry<Integer, HashMap<Automobile, Integer>>> iterator = orders.entrySet().iterator();
        while (iterator.hasNext()) {
            double peopleCapacity = 0;
            double cargoCapacity = 0;
            double price = 0;
            Map.Entry<Integer, HashMap<Automobile, Integer>> entry = iterator.next();
            System.out.println("订单" + entry.getKey() + ":");
            Iterator<Map.Entry<Automobile, Integer>> entryIterator = entry.getValue().entrySet().iterator();
            while (entryIterator.hasNext()) {
                Map.Entry<Automobile, Integer> next = entryIterator.next();
                System.out.println("<" + next.getKey().getBrand() + "," + next.getValue() + "天>");
                price += next.getKey().getPrice();
                if (next.getKey() instanceof Car) {
                    peopleCapacity += ((Car) next.getKey()).getPeopleCapacity();
                } else if (next.getKey() instanceof PickUp) {
                    peopleCapacity += ((PickUp) next.getKey()).getPeopleCapacity();
                }
                if (next.getKey() instanceof Truck) {
                    cargoCapacity += ((Truck) next.getKey()).getCargoCapacity();

                } else if (next.getKey() instanceof PickUp) {
                    cargoCapacity += ((PickUp) next.getKey()).getCargoCapacity();
                }
            }
            System.out.println("总载客量" + peopleCapacity + "人");
            System.out.println("总载货量" + cargoCapacity + "吨");
            System.out.println("总租车价" + price + "元");
        }
            System.out.println("是否继续: Y or N ?");

            String option = RentSysConst.INPUT.next();

            if(option.equals("Y")){
                flag = 1;

            }
            else if(option.equals("N")){
                flag = 0;

            }

        return flag;

    }//展示订单

    public void init(){

            showMenu();
            chooseAutomobiles();

    }//初始化租车系统

}
