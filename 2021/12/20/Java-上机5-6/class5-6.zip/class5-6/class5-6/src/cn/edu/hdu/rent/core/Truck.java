package cn.edu.hdu.rent.core;


import cn.edu.hdu.rent.util.CanCarryCargo;

public class Truck extends Automobile implements CanCarryCargo {
    private double cargoCapacity;

    @Override
    public void setCargoCapacity(double capacity) {
        this.cargoCapacity = capacity;
    }

    @Override
    public double getCargoCapacity() {
        return this.cargoCapacity;
    }
}
