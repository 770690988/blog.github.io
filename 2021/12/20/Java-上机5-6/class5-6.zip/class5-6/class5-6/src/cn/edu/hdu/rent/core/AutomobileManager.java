package cn.edu.hdu.rent.core;

import cn.edu.hdu.account.core.IllegalInputException;
import cn.edu.hdu.rent.util.Management;
import cn.edu.hdu.rent.util.RentSysConst;

import java.util.Iterator;
import java.util.Map;

public class AutomobileManager implements Management {

    @Override
    public void add(int type) throws IllegalInputException {
        //添加汽车
        String brand;
        double price;
        switch (type){
            case 1:{
                System.out.println("请输入品牌");
                brand = RentSysConst.INPUT.next();
                System.out.println("请输入佣金");
                price = RentSysConst.INPUT.nextDouble();
                System.out.println("请输入载人量：");
                double peopleCapacity = RentSysConst.INPUT.nextDouble();
                Car car=new Car();
                car.setBrand(brand);
                car.setPeopleCapacity(peopleCapacity);
                car.setPrice(price);
                RentSysConst.AUTO_LIST.put(RentSysConst.AUTO_ID+1,car);
                RentSysConst.AUTO_ID++;
                break;
            }
            case 2:{
                System.out.println("请输入品牌");
                brand = RentSysConst.INPUT.next();
                System.out.println("请输入佣金");
                price = RentSysConst.INPUT.nextDouble();
                System.out.println("请输入载货量：");
                double cargoCapacity = RentSysConst.INPUT.nextDouble();
                Truck truck = new Truck();
                truck.setCargoCapacity(cargoCapacity);
                truck.setBrand(brand);
                truck.setPrice(price);
                RentSysConst.AUTO_LIST.put(RentSysConst.AUTO_ID+1,truck);
                RentSysConst.AUTO_ID++;
                break;
            }
            case 3:{
                System.out.println("请输入品牌");
                brand = RentSysConst.INPUT.next();
                System.out.println("请输入佣金");
                price = RentSysConst.INPUT.nextDouble();
                System.out.println("请输入载人量：");
                double peopleCapacity = RentSysConst.INPUT.nextDouble();
                System.out.println("请输入载货量：");
                double cargoCapacity = RentSysConst.INPUT.nextDouble();
                PickUp pickUp = new PickUp();
                pickUp.setPeopleCapacity(peopleCapacity);
                pickUp.setCargoCapacity(cargoCapacity);
                pickUp.setBrand(brand);
                pickUp.setPrice(price);
                RentSysConst.AUTO_LIST.put(RentSysConst.AUTO_ID+1,pickUp);
                RentSysConst.AUTO_ID++;
                break;
            }
            default:{
                throw new IllegalInputException(type);
            }

        }


    }

    @Override
    public void delete(int ID) {
        RentSysConst.AUTO_LIST.remove(ID);
    }

    @Override
    public void update(int ID) {
    }

    @Override
    public void show(){
        //显示已经汽车列表
        Iterator<Map.Entry<Integer, Automobile>> iterator = RentSysConst.AUTO_LIST.entrySet().iterator();
        System.out.printf("%-10s\t%-10s\t%-10s\t%-10s\t%-10s%n","序号","汽车名称","租金","载客量","载货量");
        while (iterator.hasNext()){
            Map.Entry<Integer, Automobile> entry = iterator.next();
            if(entry.getValue() instanceof Car){
                Car car = (Car)entry.getValue();
                System.out.printf("%-10s\t%-15s\t%-10s\t%-15s\t%-10s%n",entry.getKey(),car.getBrand(),car.getPrice(),car.getPeopleCapacity(),"0.0");
            }
            else if(entry.getValue() instanceof Truck){
                Truck truck = (Truck) entry.getValue();
                System.out.printf("%-10s\t%-15s\t%-10s\t%-15s\t%-10s%n",entry.getKey(),truck.getBrand(),truck.getPrice(),"0.0",truck.getCargoCapacity());
            }
            else if(entry.getValue() instanceof PickUp){
                PickUp pickUp = (PickUp) entry.getValue();
                System.out.printf("%-10s\t%-15s\t%-10s\t%-15s\t%-10s%n",entry.getKey(),pickUp.getBrand(),pickUp.getPrice(),pickUp.getPeopleCapacity(),pickUp.getCargoCapacity());
            }


        }
    }

    @Override
    public int exit() {
        //退出函数
       return 0;
    }

    public void init(){
        int flag = 1;
            while (flag == 1){
                showMenu();
                try{
                    flag = getUserInput();
                }catch (IllegalInputException e){
                    System.out.println("输入了无效信息，请重新输入");
                }
            }
    }; //初始化管理系统

    public void showMenu(){
        System.out.println("=========汽车管理系统=========");
        System.out.println("1.增加汽车");
        System.out.println("2.删除汽车");
        System.out.println("3.显示汽车");
        System.out.println("4.退出系统");

    }; //显示管理系统界面

    private int getUserInput() throws IllegalInputException {

        int choice = RentSysConst.INPUT.nextInt();
        int type = 0;
        switch (choice){
            case 1:{
                System.out.println("请输入汽车类型(1-汽车,2-卡车,3-皮卡):");
                type = RentSysConst.INPUT.nextInt();
                add(type);
                break;
            }
            case 2:{
                System.out.println("请输入要删除的汽车ID");
                type = RentSysConst.INPUT.nextInt();
                delete(type);
                break;
            }
            case 3:{
                show();
                break;
            }
            case 4:{
                return exit();
            }
            default:{
                throw new IllegalInputException(choice);
            }
        }
        return 1;
    }; //处理逻辑



}
