package cn.edu.hdu.rent.util;

public interface CanCarryCargo {
    void setCargoCapacity(double capacity); //设置载货量
    double getCargoCapacity(); //获取载货量

}
