package cn.edu.hdu.rent.util;

import cn.edu.hdu.rent.core.Automobile;

import java.util.HashMap;
import java.util.Scanner;

public class RentSysConst {
    public static HashMap<Integer, Automobile> AUTO_LIST =
            new HashMap<Integer,Automobile>();
    public static int AUTO_ID;
    public static Scanner INPUT = new Scanner(System.in);

}
