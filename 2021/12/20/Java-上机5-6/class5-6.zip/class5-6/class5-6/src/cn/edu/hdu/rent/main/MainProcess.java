package cn.edu.hdu.rent.main;



import cn.edu.hdu.rent.core.AutomobileManager;
import cn.edu.hdu.rent.core.IllegalInputException;
import cn.edu.hdu.rent.core.RentSystem;

import java.util.Scanner;

public class MainProcess {
    public static void main(String[] args) throws IllegalInputException {
        Scanner sc = new Scanner(System.in);
        int choice;
        while (true) {
            System.out.println("请选择系统");
            System.out.println("1.汽车管理系统");
            System.out.println("2.租车系统");
            System.out.println("3.退出");
            System.out.println("请输入（1-3）：");
            choice = sc.nextInt();
            switch (choice) {
                case 1: {
                    AutomobileManager am = new AutomobileManager();
                    am.init();
                    break;
                }
                case 2: {
                    RentSystem rs = new RentSystem();
                    rs.init();
                    break;
                }
                case 3: {
                    System.exit(0);
                    break;
                }
                default: {
                    System.out.println("输入值无效，请重新输入");
                }
            }
        }
    }
}
