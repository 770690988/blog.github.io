package cn.edu.hdu.account.main;

import cn.edu.hdu.account.core.Account;

public class MainProcess {
    public static void main(String[] args) {
        Account account = new Account();
        account.init();
    }
}
