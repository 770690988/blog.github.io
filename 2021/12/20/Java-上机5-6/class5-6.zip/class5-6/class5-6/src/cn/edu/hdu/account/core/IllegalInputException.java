package cn.edu.hdu.account.core;

public class IllegalInputException extends Exception{
    //这个变量用来记录用户输入的参数异常，比如输入5那么input就是5
    private int input;
    //构造函数，用异常输入来创建异常类
    public IllegalInputException(int input){
        this.input = input;
        System.out.println("请输入1~4的整数");
    }
    public void InputMismatchException(String m){
        System.out.println("请输入1~4的整数");
    }
    //用于获取该异常参数
    public int getInput(){
        return this.input;
    }
}
