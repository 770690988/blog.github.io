package cn.edu.hdu.account.core;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class Account implements AccountFeature{
    private double balance;
    private ArrayList<Record> records;
    Scanner input = new Scanner(System.in);

    @Override
    public void showMainMenu() {//显示主菜单
        System.out.println("------------家用收支记账软件-----------");
        System.out.println("1. 收支明细");
        System.out.println("2. 登记收入");
        System.out.println("3. 登记支出");
        System.out.println("4. 退出");
        System.out.println("请选择(1~4)");

    }

    @Override
    public void showDetailInfo() {//显示账单信息
        System.out.println("--------------当前收支明细记录------------------------------------");
        System.out.printf("%-10s\t%-10s\t%-10s\t%-10s\t%-10s%n", "收支", "账户金额", "收支金额", "说明", "时间");
        //循环遍历账本records中的每个记录，一次输出其变量信息
        //输出格式"%-10s\t%-10s\t%-10s\t%-10s\t%-10s%n",依次输出收支类型/账户当时余额/单笔记录金额、备注、时间
        Record record = new Record();
        for (int i = 0; i < records.size(); i++) {
            record = records.get(i);
            System.out.printf("%-10s\t%-15s\t%-15s\t%-10s\t%-10s%n",record.getRecordType(),record.getCurBalance(),record.getAmountOfMoney(),record.getRemark(),record.getDate());
        }
    }

    @Override
    public void editIncomeInfo() {//登记收入信息
        //编辑收入信息，收入信息包括：记录类型、当前余额、单笔金额、备注、时间
        //分别获得这些信息，然后调用setRecord函数，将这些信息写入记录
        //当前余额的计算通过updateBalance函数完成
        System.out.println("本次收入金额");
        Double money = input.nextDouble();
        System.out.println("本次收入说明");
        String remark = input.next();
        String type = "收入";
        updateBalance("+",money);
        setRecord(type,this.balance,money,remark,new Date());
    }

    @Override
    public void editSpendInfo() {//登记支出信
        //编辑支出信息，收入信息包括：记录类型、当前余额、单笔记录金额、备注、时间
        //分别获得这些信息，然后调用setRecord函数，将这些信息写入记录
        //当前余额的计算通过updateBalance函数完成
        System.out.println("本次支出金额");
        Double money = input.nextDouble();
        System.out.println("本次支出说明");
        String remark = input.next();
        String type = "支出";
        updateBalance("-",money);
        setRecord(type,this.balance,money,remark,new Date());
    }

    @Override
    public void exitAccount() {//退出记账器
        System.exit(0);
    }

    public void init(){//初始化账本
        this.balance = 0.0;
        this.records = new ArrayList<Record>();
        while(true){
            //在一个循环中不断显示主菜单showMainMenu,并获取用户输入gerUserInput
            //捕获在getUserInput中可能出现的输入异常，进行异常处理（这里的异常处理就是提示用户信息输错了，请重新输入
            showMainMenu();
            try{
                getUserInput();
            } catch (IllegalInputException e) {
                System.out.println();
            }

        }
    }

    private void getUserInput() throws IllegalInputException {//处理逻辑
        int choice = input.nextInt();//获取用户的输入
        switch (choice){
            case 1: {
                //显示账本详情
                showDetailInfo();
                break;
            }
            case 2: {
                //编辑收入信息
                editIncomeInfo();
                break;
            }
            case 3: {
                //编辑支出信息
                editSpendInfo();
                break;
            }
            case 4:{
                //退出账本系统
                exitAccount();
                break;
            }
            default:{
                //即输入异常，则抛出IllegalInputException异常
                throw new IllegalInputException(choice);
            }
        }
    }

    private void setRecord(String type, double balance, double money, String remark, Date date){//维护账单
        //新建一个Record对象，将参数中的信息置入这俄格Record对象
        //并将该Record对象作为记录加入账本的records列表中
        Record record = new Record();
        record.setRecordType(type);
        record.setCurBalance(balance);
        record.setAmountOfMoney(money);
        record.setRemark(remark);
        record.setDate(date);
        records.add(record);
    }

    private void updateBalance(String op, double money){//维护余额
        //根据参数op所指的操作（+或—），完成余额balance的更新
        switch (op){
            case "+": {
                this.balance+= money;
                break;
            }
            case "-": {
                this.balance-= money;
                break;
            }
        }
    }
}
