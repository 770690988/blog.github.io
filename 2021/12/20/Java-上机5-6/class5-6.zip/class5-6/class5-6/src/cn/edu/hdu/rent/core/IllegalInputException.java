package cn.edu.hdu.rent.core;

public class IllegalInputException extends Exception{
    private int input;
    public IllegalInputException(int input){
        this.input = input;
    }
    public int getInput(){
        return this.input;
    }
}
