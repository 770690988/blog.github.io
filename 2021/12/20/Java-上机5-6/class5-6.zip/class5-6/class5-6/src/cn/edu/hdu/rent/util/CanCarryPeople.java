package cn.edu.hdu.rent.util;

public interface CanCarryPeople {
    void setPeopleCapacity(double capacity); //设置载客量
    double getPeopleCapacity(); //获取载客量

}
