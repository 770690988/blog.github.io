package cn.edu.hdu.rent.core;

public class Automobile {
    private String brand;	 //品牌
    private double price;    //价格

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }
}
